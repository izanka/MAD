package com.example.student.tute_04;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.student.tute_04.Database.DBHelper;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener {

    Button signIn, add, delete, update, selectall;
    TextView uName, pwd;
    DBHelper dbHelper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        dbHelper = new DBHelper(this);
        signIn = (Button)findViewById(R.id.btnSign);
        add = (Button)findViewById(R.id.btnAdd);
        delete = (Button)findViewById(R.id.btnDelete);
        update = (Button)findViewById(R.id.btnUpdate);
        selectall = (Button)findViewById(R.id.btnSelectAll);

        uName = (TextView)findViewById(R.id.txtUserName);
        pwd = (TextView)findViewById(R.id.txtPwd);

        signIn.setOnClickListener(this);
        add.setOnClickListener(this);
        delete.setOnClickListener(this);
        update.setOnClickListener(this);
        selectall.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {

    }

    private void loginUser() {
        String uname = uName.getText().toString();
        String pswd = pwd.getText().toString();
        if(!uname.equals("")) {
            //if()
        }
    }
}
