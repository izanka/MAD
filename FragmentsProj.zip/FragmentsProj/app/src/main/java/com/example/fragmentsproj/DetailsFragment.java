package com.example.fragmentsproj;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import org.w3c.dom.Text;

public class DetailsFragment extends Fragment {
    TextView name, description;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.details_info, container, false);
        name = (TextView) view.findViewById(R.id.Name);
        description = (TextView) view.findViewById(R.id.Description);

        return view;
    }
    public void change(String uname, String udescription){
        name.setText(uname);
        description.setText(udescription);
    }
}
