package com.example.fragmentsproj;

import android.os.Bundle;
import android.support.v4.app.ListFragment;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class ListMenuFragment extends ListFragment {
    String[] characters = new String[] {
            "Godric Gryffindor",
            "Harry Potter",
            "Hermione Granger",
            "Ron Weasley",
            "Minerva McGonagall",
            "James Potter"
    };
    String[] description = new String[]{
            "One of the four Hogwarts founders. His sword may present itself to a worthy Gryffindor in times of need",
            "Harry Potter is The Boy Who Lived, singled out by Lord Voldemort at birth to be his greatest rival," +
                    " and our hero","From bookish Muggle-born to one of Gryffindor's bravest",
            "One of Harry Potter’s two best friends, fellow Gryffindor, and youngest Weasley son",
            "The strict but fair Head of Gryffindor house and Transfiguration teacher",
            "Harry's father, and a member of the Marauders and the first Order of the Phoenix. Murdered by Voldemort during the First Wizarding War"
    };

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view =inflater.inflate(R.layout.listitems_info, container, false);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getActivity(),
                android.R.layout.simple_list_item_1, characters);
        setListAdapter(adapter);
        return view;
    }
    @Override
    public void onListItemClick(ListView l, View v, int position, long id) {
        DetailsFragment txt = (DetailsFragment)getFragmentManager().findFragmentById(R.id.fragment2);
        txt.change("Character: "+ characters[position],"Description : "+ description[position]);
        getListView().setSelector(android.R.color.holo_blue_dark);
    }
}
