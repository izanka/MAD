package kalindu.courseapp.Database;

import android.provider.BaseColumns;

public final class UsersMaster {
    private UsersMaster() {
    }

    protected static class Users implements BaseColumns {
        public static final String TABLE_NAME = "users";
        public static final String COLUMN_NAME_UNAME = "username";
        public static final String COLUMN_NAME_UPASS = "password";
        public static final String COLUMN_NAME_TYPE = "type";
    }

    protected static class Messages implements BaseColumns {
        public static final String TABLE_NAME = "messages";
        public static final String COLUMN_NAME_USER = "user";
        public static final String COLUMN_NAME_SUBJECT = "subject";
        public static final String COLUMN_NAME_MESSAGE = "message";
    }
}
