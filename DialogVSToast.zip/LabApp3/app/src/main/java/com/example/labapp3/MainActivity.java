package com.example.labapp3;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private final Context context = this;
    private EditText etName, etEmail;
    private Button btnClick;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etName = findViewById(R.id.editName);
        etEmail = findViewById(R.id.editEmail);
        btnClick = findViewById(R.id.btnAlert);

    }

    public void showDialog(View view){
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);

        alertDialogBuilder.setNegativeButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                dialog.cancel();
            }
        });
       // alertDialogBuilder.setTitle("Your Inputs...");
        alertDialogBuilder.setMessage("Hi " + etName.getText().toString()+"\n Your email " + etEmail.getText().toString());
        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

    public void showToast(View view){
        Context context = getApplicationContext();
        CharSequence msg = "Input 1: "+etName.getText()+"\nInupt 2: "+etEmail.getText();
        int dur = Toast.LENGTH_LONG;
        Toast toast = Toast.makeText(context, msg, dur);
        toast.setGravity(Gravity.BOTTOM|Gravity.CENTER_VERTICAL, 0, 0);
        toast.show();
    }


}
