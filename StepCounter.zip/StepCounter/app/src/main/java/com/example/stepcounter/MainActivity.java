package com.example.stepcounter;

import android.content.Context;
import android.content.SharedPreferences;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements SensorEventListener {


    private TextView noOfSteps;
    private SensorManager sensorManager;
    private Sensor mySensor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        noOfSteps = findViewById(R.id.noOfSteps);

        // Create the sensor manager
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);

        // Assign the Step Counter sensor to sensor object
        mySensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);

        // Register the sensor with sensor listener
        sensorManager.registerListener((SensorEventListener) this, mySensor, SensorManager.SENSOR_DELAY_NORMAL);

    }

    @Override
    public void onSensorChanged(SensorEvent sensorEventvent) {
        if(sensorEventvent.sensor.getType() == Sensor.TYPE_STEP_DETECTOR){
            // get the step count

            //assign the step count to the textview

           noOfSteps.setText("No of Steps: " + sensorEventvent.values[0]);
        }

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    @Override
    protected void onPause() {

        super.onPause();

        //Unregister the listener
        if (mySensor != null) {
            sensorManager.unregisterListener(this, mySensor );
        }
    }

    public void save (View view){
        SharedPreferences sharedPreferences = getSharedPreferences("MyData" , Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("numberOfSteps", noOfSteps.getText().toString());
        editor.commit();

        Toast.makeText(this, "Data Saved Successfully", Toast.LENGTH_LONG).show();
    }

}
