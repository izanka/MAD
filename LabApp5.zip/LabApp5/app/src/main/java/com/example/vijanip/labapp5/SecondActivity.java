package com.example.vijanip.labapp5;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {
    String num1, num2;
    double res;
    TextView result;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.second_activity);

        // Get the Intent that started this activity and extract the string
        Intent intent = getIntent();
        num1 = intent.getStringExtra(FirstActivity.EXTRA_MESSAGE1);
        num2 = intent.getStringExtra(FirstActivity.EXTRA_MESSAGE2);

        // Capture the layout's TextView and set the string as its text
        TextView textView1 = findViewById(R.id.num1Text);
        textView1.setText(num1);
        TextView textView2 = findViewById(R.id.num2Text);
        textView2.setText(num2);

        result = findViewById(R.id.ansTextView);

    }


    public void addNumbers(View view){
        res = Double.parseDouble(num1)+ Double.parseDouble(num2);
        result.setText(num1 + " + " + num2 + " = " + Double.toString(res));
    }
    public void subtractNumbers(View view){
        res = Double.parseDouble(num1)-Double.parseDouble(num2);
        result.setText(num1 + " - " + num2 + " = " + Double.toString(res));
    }
    public void multiplyNumbers(View view){
        res = Double.parseDouble(num1)* Double.parseDouble(num2);
        result.setText(num1 + " * " + num2 + " = " + Double.toString(res));
    }
    public void divideNumbers(View view){
        res = Double.parseDouble(num1)/ Double.parseDouble(num2);
        result.setText(num1 + " / " + num2 + " = " + Double.toString(res));
    }
}
