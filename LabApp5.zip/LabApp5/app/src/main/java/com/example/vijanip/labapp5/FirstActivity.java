package com.example.vijanip.labapp5;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class FirstActivity extends AppCompatActivity {
    public static final String EXTRA_MESSAGE1 = "com.example.vijanip.labapp5.MESSAGE1";
    public static final String EXTRA_MESSAGE2 = "com.example.vijanip.labapp5.MESSAGE2";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.first_activity);
    }

    public void sendNumbers(View view){
        Intent intent= new Intent(this,SecondActivity.class);
        EditText number1Text=(EditText)findViewById(R.id.enterNumber1);
        EditText number2Text=(EditText)findViewById(R.id.enterNumber2);
        String number1 = number1Text.getText().toString();
        String number2 = number2Text.getText().toString();
        intent.putExtra(EXTRA_MESSAGE1, number1);
        intent.putExtra(EXTRA_MESSAGE2, number2);
        startActivity(intent);
    }

}
